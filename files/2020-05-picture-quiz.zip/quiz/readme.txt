ROUNDS

Round 1 - is satellite photos of places from about.

Round 2 - famous arses. Zoomed up pictures of arses

Round 3 - Guess the musician

Round 4 - Cheese

Round 5 - Cinema. Movie posters with no titles

Round 6 - Colors - guess the colour name. Closest/funniest wins. You could give points out of 5 for how good the answers are.

Round 7 - Stolen questions. 1 point for the right answer. 1 point for what TV show it was nicked from.

Round 8 - Logos. Guess the logo.
